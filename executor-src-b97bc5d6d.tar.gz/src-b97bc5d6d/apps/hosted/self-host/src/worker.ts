/** Product Worker. One durable actor owns PostgreSQL, auth, sessions and background work. */
import * as BrowserCrypto from "@effect/platform-browser/BrowserCrypto";
import { DurableObject, WorkerEntrypoint } from "cloudflare:workers";
import type { DurableObjectState, Fetcher } from "@cloudflare/workers-types";
import { PGlite } from "@electric-sql/pglite";
import { PgliteClient } from "@effect/sql-pglite";
import { executorSkillFiles } from "@executor-js/app-templates/executor";
import { bindingWorkerdApps } from "@executor-js/sdk/workerd";
import { ScheduleHostReady } from "@executor-js/sdk/scheduling";
import { telemetryConfig, telemetryLayer } from "@executor-js/telemetry";
import { CurrentTelemetryClient } from "@executor-js/telemetry/transport";
import { urlPolicyConfig } from "@executor-js/utils/url-policy";
import {
  Cause,
  Config,
  ConfigProvider,
  Context,
  Effect,
  Exit,
  Layer,
  Option,
  Schema,
  Scope,
} from "effect";
import {
  FetchHttpClient,
  HttpEffect,
  HttpRouter,
  HttpServer,
  HttpServerRequest,
} from "effect/http";
import { FirstPartyOAuthClientsInvalid } from "@executor-js/hosted-server";
import { selfHostDatabaseSchema } from "./implementation/database-schema.ts";
import {
  selfHostExecutorServices,
  SelfHostWorkflowRequests,
} from "./implementation/executor-services.ts";
import { selfHostRouteMap } from "./implementation/routes.ts";
import {
  bindingBlobStore,
  bindingDashboard,
  bindingHttpClient,
  bindingRepositories,
  bindingTelemetryClient,
  collectorOrigin,
  type HttpBinding,
} from "./implementation/workerd/bindings.ts";
import {
  prepareProductFilesystem,
  completeProductBootstrap,
} from "./implementation/workerd/storage-migration.ts";
import skills from "executor:skills";
import dashboard from "executor:dashboard";
import pgliteWasmModule from "executor:pglite.wasm";
import initdbWasmModule from "executor:initdb.wasm";
import pgliteData from "executor:pglite.data";

interface ProductStub {
  fetch(request: Request): Promise<Response>;
  workflow(request: Request): Promise<Response>;
  exportDatabase(): Promise<Response>;
}
interface Environment {
  readonly PRODUCT: { getByName(name: string): ProductStub };
  readonly LEGACY_DATABASE: HttpBinding;
  readonly NATIVE: HttpBinding;
  readonly BLOBS: HttpBinding;
  readonly DASHBOARD: HttpBinding;
  readonly PUBLIC_FETCH: HttpBinding;
  readonly PRIVATE_FETCH: HttpBinding;
  /** The bundled collector's private Unix socket, which the host connects. */
  readonly MOTEL: HttpBinding;
  /** This product's own `SelfOrigin` entrypoint, for requests to the dashboard origin. */
  readonly SELF: HttpBinding;
  readonly APPS: Fetcher;
}

const configuration = (native: HttpBinding) =>
  Effect.tryPromise({
    try: async () => {
      const response = await native.fetch(new Request("http://native.internal/configuration"));
      if (!response.ok) throw new Error("Cannot read host configuration");
      return response.json();
    },
    catch: () => new Error("Cannot read host configuration"),
  }).pipe(Effect.flatMap(Schema.decodeUnknownEffect(Schema.Record(Schema.String, Schema.String))));

const prepare = (state: DurableObjectState, env: Environment) =>
  Effect.gen(function* () {
    const fs = yield* prepareProductFilesystem(state.storage, env.LEGACY_DATABASE);
    const pg = yield* Effect.acquireRelease(
      Effect.tryPromise(async () => {
        const pg = new PGlite({
          fs,
          pgliteWasmModule,
          initdbWasmModule,
          fsBundle: new Blob([pgliteData]),
          parsers: { 1082: (value) => value, 1114: (value) => value },
        });
        await pg.waitReady;
        return pg;
      }),
      (pg) => Effect.promise(() => pg.close()),
    );
    yield* completeProductBootstrap(state.storage);
    const exportDatabase = async () =>
      new Response(await pg.dumpDataDir("none"), {
        headers: { "content-type": "application/x-tar" },
      });
    if (yield* Config.Boolean("EXECUTOR_STORAGE_EXPORT").pipe(Config.withDefault(false)))
      return {
        fetch: async (_request: Request) => new Response(null, { status: 503 }),
        workflow: async (_request: Request) => new Response(null, { status: 503 }),
        exportDatabase,
      };
    const telemetry = yield* telemetryConfig("executor-selfhost");
    const common = yield* Layer.build(
      Layer.mergeAll(
        selfHostDatabaseSchema.pipe(Layer.provideMerge(PgliteClient.layer({ liveClient: pg }))),
        telemetry.traces === undefined && telemetry.logs === undefined
          ? telemetryLayer({
              ...telemetry,
              traces: { url: `${collectorOrigin}/v1/traces` },
              logs: { url: `${collectorOrigin}/v1/logs` },
            }).pipe(
              Layer.provideMerge(
                Layer.effect(CurrentTelemetryClient, bindingTelemetryClient(env.MOTEL)),
              ),
            )
          : telemetryLayer(telemetry),
        HttpServer.layerServices,
        BrowserCrypto.layer,
        Layer.succeed(ScheduleHostReady, Effect.void),
      ),
    );
    return yield* Effect.gen(function* () {
      const policy = yield* urlPolicyConfig;
      const egress = {
        policy,
        client: yield* bindingHttpClient(policy, env.PUBLIC_FETCH, env.PRIVATE_FETCH, {
          origin: yield* Config.String("BETTER_AUTH_URL"),
          binding: env.SELF,
        }),
      };
      const blobs = bindingBlobStore(env.BLOBS);
      const directory = yield* Config.NonEmptyString("EXECUTOR_REPOSITORIES_DIR");
      const services = yield* Layer.build(
        selfHostExecutorServices(egress, () =>
          Effect.gen(function* () {
            const host = yield* bindingWorkerdApps({
              binding: env.APPS,
              authorization: "service-binding",
              blobs,
            });
            return { ...host, blobs, repositories: bindingRepositories(env.NATIVE, directory) };
          }),
        ),
      );
      const routes = yield* selfHostRouteMap({
        skills: executorSkillFiles(skills),
        egress,
        executorServices: Layer.succeedContext(services),
        dashboard: bindingDashboard(env.DASHBOARD, dashboard),
      });
      const http = yield* HttpRouter.toHttpEffect(routes).pipe(
        Effect.provideService(Layer.CurrentMemoMap, yield* Layer.makeMemoMap),
      );
      const workflow = Context.get(services, SelfHostWorkflowRequests);
      const context = yield* Effect.context<never>();
      const addressed = Effect.gen(function* () {
        const request = yield* HttpServerRequest.HttpServerRequest;
        return yield* http.pipe(
          Effect.provideService(
            HttpServerRequest.HttpServerRequest,
            request.modify({
              remoteAddress: Option.fromUndefinedOr(request.headers["x-executor-client-ip"]),
            }),
          ),
        );
      });
      return {
        fetch: HttpEffect.toWebHandlerWith<never, Effect.Services<typeof addressed>>(context)(
          addressed,
        ),
        workflow: HttpEffect.toWebHandlerWith<never, Effect.Services<typeof workflow>>(context)(
          workflow,
        ),
        exportDatabase,
      };
    }).pipe(Effect.provideContext(common));
  });

/**
 * The product store has its own disk service, namespace and migration journal.
 *
 * Opening it runs schema migrations and data steps, which can take longer on a large install than
 * workerd allows a `blockConcurrencyWhile` callback: after 30 seconds workerd cancels the callback
 * and resets the object. So the store opens outside it, and every entry point waits for the open
 * product instead. Nothing is served, built or run in the background before the open finishes.
 */
export class ExecutorProduct extends DurableObject<Environment> implements ProductStub {
  readonly #state: DurableObjectState;
  readonly #env: Environment;
  #opening: Promise<Effect.Success<ReturnType<typeof prepare>>> | undefined;
  constructor(state: DurableObjectState, env: Environment) {
    super(state, env);
    this.#state = state;
    this.#env = env;
    // Start at once, as after a restart; a failure is reported to the events that wait for it.
    this.#product().catch(() => undefined);
  }
  /** The open product. A failed open releases what it acquired, and the next event retries it. */
  #product() {
    this.#opening ??= this.#open().catch((error: unknown) => {
      this.#opening = undefined;
      throw error;
    });
    return this.#opening;
  }
  async #open() {
    const scope = Scope.makeUnsafe();
    // Invalid operator settings say which setting and field, never a value, so they are reported
    // as they are; any other failure keeps the storage report.
    let settings: string | undefined;
    try {
      const config = await Effect.runPromise(configuration(this.#env.NATIVE));
      const opened = await Effect.runPromiseExit(
        prepare(this.#state, this.#env).pipe(
          Effect.provideService(Scope.Scope, scope),
          Effect.provide(ConfigProvider.layer(ConfigProvider.fromUnknown(config))),
          Effect.provide(FetchHttpClient.layer),
        ),
      );
      if (Exit.isSuccess(opened)) {
        await this.#state.storage.setAlarm(Date.now() + 30_000);
        return opened.value;
      }
      const error = Cause.findErrorOption(opened.cause);
      if (Option.isSome(error) && Schema.is(FirstPartyOAuthClientsInvalid)(error.value))
        settings = error.value.message;
    } catch {
      // Reported below.
    }
    await Effect.runPromise(Scope.close(scope, Exit.void));
    throw new Error(
      settings ??
        "Executor product storage could not open. The original PostgreSQL directory has been preserved.",
    );
  }
  /** Dispatch the existing authenticated product routes. */
  async fetch(request: Request): Promise<Response> {
    return (await this.#product()).fetch(request);
  }
  /** Private workflow callbacks are reached only through the named service entrypoint. */
  async workflow(request: Request): Promise<Response> {
    return (await this.#product()).workflow(request);
  }
  /** The offline export process owns the volume lock; no public socket serves this method. */
  async exportDatabase(): Promise<Response> {
    return (await this.#product()).exportDatabase();
  }
  /** Restore the background owner after a restart even when no public request arrives. */
  async alarm(): Promise<void> {
    await this.#product();
    await this.#state.storage.setAlarm(Date.now() + 30_000);
  }
}

/** Private service binding used by the workerd workflow engine. */
export class WorkflowCallbacks extends WorkerEntrypoint<Environment> {
  async fetch(request: Request): Promise<Response> {
    return this.env.PRODUCT.getByName("product").workflow(request);
  }
}

/**
 * Requests this instance sends to its own dashboard origin, from app isolates or host egress.
 * They never cross the network, so they carry a fixed internal source instead of any client
 * address header the sender supplied.
 */
export class SelfOrigin extends WorkerEntrypoint<Environment> {
  async fetch(request: Request): Promise<Response> {
    const internal = new Request(request);
    internal.headers.set("x-executor-client-ip", "127.0.0.1");
    return this.env.PRODUCT.getByName("product").fetch(internal);
  }
}

/** Only the offline supervisor binds a socket to this entrypoint. */
export class ProductExport extends WorkerEntrypoint<Environment> {
  async fetch(): Promise<Response> {
    return this.env.PRODUCT.getByName("product").exportDatabase();
  }
}

/** Public traffic can only reach the product's authenticated route map. */
export default {
  fetch(request: Request, env: Environment): Promise<Response> {
    return env.PRODUCT.getByName("product").fetch(request);
  },
};
